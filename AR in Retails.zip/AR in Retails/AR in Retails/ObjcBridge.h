//
//  ObjcBridge.h
//  AR in Retails
//
//  Created by Ashis Laha on 4/9/18.
//  Copyright © 2018 Ashis Laha. All rights reserved.
//

#ifndef ObjcBridge_h
#define ObjcBridge_h


#import "EILIndoorSDK.h"
#import <EstimoteSDK/EstimoteSDK.h>

#endif /* ObjcBridge_h */
