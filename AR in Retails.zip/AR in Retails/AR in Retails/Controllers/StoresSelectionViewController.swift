//
//  ViewController.swift
//  AR in Retails
//
//  Created by Ashis Laha on 4/7/18.
//  Copyright © 2018 Ashis Laha. All rights reserved.
//

import UIKit

class StoresSelectionViewController: UIViewController {

    let stores: [String] = ["Store1", "Store2", "Store3", "Store4"]
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension StoresSelectionViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else { return UITableViewCell() }
        cell.textLabel?.text = stores[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        pushStoreIdentifyVC(storeIndex: indexPath.row)
    }
}

extension StoresSelectionViewController {
    
    public func pushStoreIdentifyVC(storeIndex: Int) {
        guard let store = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StoreIdentifyViewController") as? StoreIdentifyViewController else { return }
        navigationController?.pushViewController(store, animated: true)
    }
}
