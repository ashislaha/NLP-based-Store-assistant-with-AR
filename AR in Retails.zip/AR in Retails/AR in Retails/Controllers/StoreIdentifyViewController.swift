//
//  StoreIdentifyViewController.swift
//  AR in Retails
//
//  Created by Ashis Laha on 4/9/18.
//  Copyright © 2018 Ashis Laha. All rights reserved.
//

import UIKit

class StoreIdentifyViewController: UIViewController, EILIndoorLocationManagerDelegate {

    let locationManager = EILIndoorLocationManager()
    
    @IBOutlet weak var storePlan: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        navigationItem.title = "Store plan"
        addRightBarButtonItem()
    }
    
    private func addRightBarButtonItem() {
        let barbuttonItem = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(tappedARView))
        navigationItem.rightBarButtonItem = barbuttonItem
    }
    
    @objc func tappedARView() {
        pushARVC()
    }
}

extension StoreIdentifyViewController {
    
    public func pushARVC() {
        guard let arVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ARViewController") as? ARViewController else { return }
        arVC.productData = "Helping through AR"
        navigationController?.pushViewController(arVC, animated: true)
    }
}

// MARK: Setting up new location

extension StoreIdentifyViewController {
    
    func buildLocation() {
        let locationBuilder = EILLocationBuilder()
        let boundaryPoints: [EILPoint] = [EILPoint(x: 0, y: 0), EILPoint(x: 5, y: 0), EILPoint(x: 5, y: 5), EILPoint(x: 0, y: 5)]
        locationBuilder.setLocationBoundaryPoints(boundaryPoints)
        locationBuilder.setLocationOrientation(0)
        
        locationBuilder.addBeacon(withIdentifier: "test", atBoundarySegmentIndex: 0, inDistance: 2, from: .leftSide)
        
    }
}

