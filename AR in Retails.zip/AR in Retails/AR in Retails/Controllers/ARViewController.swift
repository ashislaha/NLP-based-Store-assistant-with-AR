//
//  ARViewController.swift
//  AR in Retails
//
//  Created by Ashis Laha on 4/7/18.
//  Copyright © 2018 Ashis Laha. All rights reserved.
//

import UIKit
import ARKit

class ARViewController: UIViewController {

    var productData: String?
    var model: ARModel?
    
    private var sceneView: ARView = {
        let sceneView = ARView()
        sceneView.orientToTrueNorth = true
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        return sceneView
    }()
    
    private func layoutSetup() {
        view.addSubview(sceneView)
        NSLayoutConstraint.activate([
            // scene view
            sceneView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            sceneView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            sceneView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            sceneView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = productData
        layoutSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sceneView.run()
        addNodesToScene()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.pause()
    }
    
    // adding nodes to scene
    private func addNodesToScene() {
        let position1 = SCNVector3Zero
        let position2 = SCNVector3Make(20, 0, 0)
        let node = SceneNodeCreator.getPathNode(position1: position1, position2: position2)
        sceneView.scene.rootNode.addChildNode(node)
    }
}
